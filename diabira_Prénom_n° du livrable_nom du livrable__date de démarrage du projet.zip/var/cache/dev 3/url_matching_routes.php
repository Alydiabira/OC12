<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/auth' => [[['_route' => 'app_auth', '_controller' => 'App\\Controller\\AuthController::index'], null, null, null, false, false, null]],
        '/conseil' => [[['_route' => 'app_conseil', '_controller' => 'App\\Controller\\ConseilController::index'], null, null, null, false, false, null]],
        '/meteo' => [[['_route' => 'app_meteo', '_controller' => 'App\\Controller\\MeteoController::index'], null, null, null, false, false, null]],
        '/user' => [[['_route' => 'app_user', '_controller' => 'App\\Controller\\UserController::index'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
