<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/auth' => [[['_route' => 'auth_login', '_controller' => 'App\\Controller\\AuthController::login'], null, ['POST' => 0], null, false, false, null]],
        '/conseil' => [
            [['_route' => 'conseil_mois_courant', '_controller' => 'App\\Controller\\ConseilController::getConseilsMoisCourant'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'conseil_create', '_controller' => 'App\\Controller\\ConseilController::createConseil'], null, ['POST' => 0], null, false, false, null],
        ],
        '/meteo' => [[['_route' => 'meteo_user', '_controller' => 'App\\Controller\\MeteoController::meteoUser'], null, ['GET' => 0], null, false, false, null]],
        '/register' => [[['_route' => 'user_register', '_controller' => 'App\\Controller\\RegisterController::register'], null, ['POST' => 0], null, false, false, null]],
        '/user' => [[['_route' => 'create_user', '_controller' => 'App\\Controller\\UserController::createUser'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/conseil/([^/]++)(?'
                    .'|(*:27)'
                    .'|(*:34)'
                .')'
                .'|/meteo/([^/]++)(*:57)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        27 => [[['_route' => 'conseil_par_mois', '_controller' => 'App\\Controller\\ConseilController::getConseilsParMois'], ['mois'], ['GET' => 0], null, false, true, null]],
        34 => [
            [['_route' => 'conseil_update', '_controller' => 'App\\Controller\\ConseilController::updateConseil'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'conseil_delete', '_controller' => 'App\\Controller\\ConseilController::deleteConseil'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        57 => [
            [['_route' => 'meteo_ville', '_controller' => 'App\\Controller\\MeteoController::meteoVille'], ['ville'], ['GET' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
